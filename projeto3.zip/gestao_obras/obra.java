package obras;

public class obra {
	int tempo;
	String nome;
	String cidade;
	
}
