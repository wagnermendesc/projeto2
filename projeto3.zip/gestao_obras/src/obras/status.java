package obras;

public class status {
	int meses;
	String andamento;
	String entrega;

}
