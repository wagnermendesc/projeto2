package obras;

public class valor {
	
	float custo;

}
