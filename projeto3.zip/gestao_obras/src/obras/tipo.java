package obras;

public class tipo {
	String escola;
	String creche;
	String universidade;

}
